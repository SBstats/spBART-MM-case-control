/*
 *  BART: Bayesian Additive Regression Trees - Stateful Sampler
 *  Modified for Semi-Parametric Probit DART Models
 *
 *  This file implements a stateful BART sampler that can be used within
 *  Gibbs samplers for semi-parametric models. Unlike the standard wbart()
 *  which runs a complete MCMC chain in one call, this implementation:
 *
 *  1. Creates a sampler object ONCE (wbart_create)
 *  2. Allows updating the response without reinitializing trees (wbart_update_response)
 *  3. Runs ONE iteration at a time (wbart_run_iteration)
 *  4. Cleans up when done (wbart_destroy)
 *
 *  This is essential for proper integration into Gibbs samplers where the
 *  BART component needs to maintain tree state across iterations.
 */

#include "tree.h"
#include "treefuns.h"
#include "info.h"
#include "bartfuns.h"
#include "bd.h"
#include "bart.h"
#include "heterbart.h"
#include "rn.h"

#ifndef NoRcpp

// Stateful sampler state structure
struct wbart_stateful_state {
  // Core BART objects
  heterbart *bm;        // BART model (tree ensemble)

  // Data pointers
  double *ix;           // Predictors (training) - FIXED
  double *ixp;          // Predictors (test) - FIXED or NULL
  double *iy;           // Response (training) - MUTABLE
  double *iw;           // Weights - FIXED

  // Dimensions
  size_t n;             // Number of training observations
  size_t p;             // Number of predictors
  size_t np;            // Number of test observations
  size_t m;             // Number of trees

  // MCMC parameters
  double sigma;         // Current sigma value
  double *allfit;       // Current fit (sum of all trees)
  double *r;            // Residuals
  double *ftemp;        // Temporary fit storage

  // Test set predictions
  double *allfit_test;  // Test set predictions (if test data provided)
  double *ftemp_test;   // Temporary test fit storage

  // Prior/model parameters
  double alpha;         // BART tree prior (base)
  double mybeta;        // BART tree prior (power)
  double tau;           // Prior on leaf parameters
  bool dart;            // Whether Dirichlet sparsity is enabled
  double a;             // Dirichlet parameter
  double b;             // Dirichlet parameter
  double rho;           // Dirichlet concentration
  std::vector<double> theta;  // Dirichlet splitting probabilities

  // RNG
  arn gen;              // R-based random number generator

  // Cutpoint information
  xinfo xi;             // Cutpoint information

  // Variable counts for PIP computation
  std::vector<int> varcnt;
};

//=============================================================================
// Create stateful BART sampler
//=============================================================================
RcppExport SEXP cwbart_create(
  SEXP _in,         // number of observations in training data
  SEXP _ip,         // dimension of x
  SEXP _inp,        // number of observations in test data
  SEXP _ix,         // x, train, pxn (transposed)
  SEXP _iy,         // y, train, nx1
  SEXP _ixp,        // x, test, pxnp (transposed)
  SEXP _im,         // number of trees
  SEXP _inc,        // number of cut points
  SEXP _ipower,     // power parameter for tree prior
  SEXP _ibase,      // base parameter for tree prior
  SEXP _itau,       // prior on leaf parameters
  SEXP _idart,      // whether to use DART
  SEXP _itheta,     // theta for DART
  SEXP _iomega,     // omega for DART
  SEXP _ia,         // a parameter for DART
  SEXP _ib,         // b parameter for DART
  SEXP _irho,       // rho parameter for DART
  SEXP _iaug,       // whether to use data augmentation
  SEXP _Xinfo       // cutpoint information
)
{
  //--------------------------------------------------------------------------
  // Process arguments
  //--------------------------------------------------------------------------
  size_t n = Rcpp::as<int>(_in);
  size_t p = Rcpp::as<int>(_ip);
  size_t np = Rcpp::as<int>(_inp);

  Rcpp::NumericVector xv(_ix);
  double *ix = &xv[0];

  Rcpp::NumericVector yv(_iy);
  double *iy = &yv[0];

  double *ixp = nullptr;
  if(np > 0) {
    Rcpp::NumericMatrix xpv(_ixp);
    ixp = &xpv[0];
  }

  size_t m = Rcpp::as<int>(_im);

  Rcpp::IntegerVector _nc(_inc);
  int *numcut = &_nc[0];

  double mybeta = Rcpp::as<double>(_ipower);
  double alpha = Rcpp::as<double>(_ibase);
  double tau = Rcpp::as<double>(_itau);

  bool dart;
  if(Rcpp::as<int>(_idart) == 1) dart = true;
  else dart = false;

  double a = Rcpp::as<double>(_ia);
  double b = Rcpp::as<double>(_ib);
  double rho = Rcpp::as<double>(_irho);

  bool aug;
  if(Rcpp::as<int>(_iaug) == 1) aug = true;
  else aug = false;

  Rcpp::NumericMatrix Xinfo(_Xinfo);

  //--------------------------------------------------------------------------
  // Allocate state structure
  //--------------------------------------------------------------------------
  wbart_stateful_state *state = new wbart_stateful_state;

  // Store dimensions
  state->n = n;
  state->p = p;
  state->np = np;
  state->m = m;

  // Store data pointers (make copies for y since it will be updated)
  state->ix = new double[p * n];
  std::copy(ix, ix + p * n, state->ix);

  state->iy = new double[n];
  std::copy(iy, iy + n, state->iy);

  if(np > 0) {
    state->ixp = new double[p * np];
    std::copy(ixp, ixp + p * np, state->ixp);
  } else {
    state->ixp = nullptr;
  }

  // Allocate uniform weights
  state->iw = new double[n];
  for(size_t i = 0; i < n; i++) state->iw[i] = 1.0;

  // Store parameters
  state->alpha = alpha;
  state->mybeta = mybeta;
  state->tau = tau;
  state->dart = dart;
  state->a = a;
  state->b = b;
  state->rho = rho;

  //--------------------------------------------------------------------------
  // Initialize cutpoints
  //--------------------------------------------------------------------------
  state->xi.resize(p);
  for(size_t i = 0; i < p; i++) {
    state->xi[i].resize(numcut[i]);
    for(size_t j = 0; j < (size_t)numcut[i]; j++) {
      state->xi[i][j] = Xinfo(i, j);
    }
  }

  //--------------------------------------------------------------------------
  // Initialize DART splitting probabilities
  //--------------------------------------------------------------------------
  state->theta.resize(p);
  if(dart) {
    // Initialize with uniform probabilities
    for(size_t i = 0; i < p; i++) {
      state->theta[i] = 1.0 / p;
    }
  }

  //--------------------------------------------------------------------------
  // Initialize sigma (use sample variance of y)
  //--------------------------------------------------------------------------
  double ybar = 0.0;
  for(size_t i = 0; i < n; i++) ybar += state->iy[i];
  ybar /= n;

  double yvar = 0.0;
  for(size_t i = 0; i < n; i++) {
    double diff = state->iy[i] - ybar;
    yvar += diff * diff;
  }
  yvar /= (n - 1);
  state->sigma = sqrt(yvar);

  //--------------------------------------------------------------------------
  // Allocate working arrays
  //--------------------------------------------------------------------------
  state->allfit = new double[n];
  state->r = new double[n];
  state->ftemp = new double[n];

  for(size_t i = 0; i < n; i++) {
    state->allfit[i] = 0.0;
    state->r[i] = state->iy[i];
    state->ftemp[i] = 0.0;
  }

  if(np > 0) {
    state->allfit_test = new double[np];
    state->ftemp_test = new double[np];
    for(size_t i = 0; i < np; i++) {
      state->allfit_test[i] = 0.0;
      state->ftemp_test[i] = 0.0;
    }
  } else {
    state->allfit_test = nullptr;
    state->ftemp_test = nullptr;
  }

  //--------------------------------------------------------------------------
  // Initialize variable counts
  //--------------------------------------------------------------------------
  state->varcnt.resize(p);
  for(size_t i = 0; i < p; i++) state->varcnt[i] = 0;

  //--------------------------------------------------------------------------
  // Create BART model
  //--------------------------------------------------------------------------
  state->bm = new heterbart(m);

  // Set priors
  state->bm->setprior(alpha, mybeta, tau);

  // Set data
  state->bm->setdata(p, n, state->ix, state->iy, numcut);

  // Set DART parameters if enabled
  if(dart) {
    state->bm->setdart(a, b, rho, aug, true);  // sparse=true for DART
    state->bm->startdart();                    // enable Dirichlet update (Linero 2018)
  }

  //--------------------------------------------------------------------------
  // Return pointer as external pointer
  //--------------------------------------------------------------------------
  Rcpp::XPtr<wbart_stateful_state> ptr(state, true);
  return ptr;
}

//=============================================================================
// Update response (y) without reinitializing trees
//=============================================================================
RcppExport SEXP cwbart_update_response(SEXP _state, SEXP _iy_new)
{
  // Get state
  Rcpp::XPtr<wbart_stateful_state> ptr(_state);
  wbart_stateful_state *state = ptr;

  // Update y
  Rcpp::NumericVector yv(_iy_new);
  double *iy_new = &yv[0];

  std::copy(iy_new, iy_new + state->n, state->iy);

  // Update residuals (r = y - allfit)
  for(size_t i = 0; i < state->n; i++) {
    state->r[i] = state->iy[i] - state->allfit[i];
  }

  return R_NilValue;
}

//=============================================================================
// Run ONE iteration from current tree state
//=============================================================================
RcppExport SEXP cwbart_run_iteration(SEXP _state)
{
  // Get state
  Rcpp::XPtr<wbart_stateful_state> ptr(_state);
  wbart_stateful_state *state = ptr;

  // Reset variable counts for this iteration
  for(size_t j = 0; j < state->p; j++) state->varcnt[j] = 0;

  //--------------------------------------------------------------------------
  // Use BART's built-in draw method which handles all trees
  //--------------------------------------------------------------------------
  // The draw() method automatically:
  // 1. Iterates through all trees
  // 2. Proposes birth/death/change/swap moves
  // 3. Updates tree structure and leaf parameters
  // 4. Updates the fit (state->bm->allfit)

  // Create sigma vector (one value per observation - use constant sigma for homoskedastic)
  std::vector<double> svec(state->n, state->sigma);

  // Draw all trees using BART's built-in method
  state->bm->draw(svec.data(), state->gen);

  //--------------------------------------------------------------------------
  // Update our state's allfit from BART model
  //--------------------------------------------------------------------------
  for(size_t i = 0; i < state->n; i++) {
    state->allfit[i] = state->bm->f(i);
  }

  //--------------------------------------------------------------------------
  // Count variables used across all trees
  //--------------------------------------------------------------------------
  std::vector<size_t>& nv = state->bm->getnv();
  for(size_t j = 0; j < state->p && j < nv.size(); j++) {
    state->varcnt[j] = nv[j];
  }

  //--------------------------------------------------------------------------
  // Compute test set predictions (if test data provided)
  //--------------------------------------------------------------------------
  if(state->np > 0) {
    state->bm->predict(state->p, state->np, state->ixp, state->allfit_test);
  }

  //--------------------------------------------------------------------------
  // Return results for this iteration
  //--------------------------------------------------------------------------
  Rcpp::List result;

  // Training fit
  Rcpp::NumericVector yhat_train(state->n);
  std::copy(state->allfit, state->allfit + state->n, yhat_train.begin());
  result["yhat.train"] = yhat_train;

  // Test fit (if available)
  if(state->np > 0) {
    Rcpp::NumericVector yhat_test(state->np);
    std::copy(state->allfit_test, state->allfit_test + state->np, yhat_test.begin());
    result["yhat.test"] = yhat_test;
  }

  // Variable counts
  Rcpp::IntegerVector varcount(state->p);
  std::copy(state->varcnt.begin(), state->varcnt.end(), varcount.begin());
  result["varcount"] = varcount;

  // Current sigma
  result["sigma"] = state->sigma;

  return result;
}

//=============================================================================
// Destroy sampler and free memory
//=============================================================================
RcppExport SEXP cwbart_destroy(SEXP _state)
{
  // Get state
  Rcpp::XPtr<wbart_stateful_state> ptr(_state);
  wbart_stateful_state *state = ptr;

  // Delete BART model
  delete state->bm;

  // Delete arrays
  delete[] state->ix;
  delete[] state->iy;
  delete[] state->iw;
  if(state->ixp) delete[] state->ixp;
  delete[] state->allfit;
  delete[] state->r;
  delete[] state->ftemp;
  if(state->allfit_test) delete[] state->allfit_test;
  if(state->ftemp_test) delete[] state->ftemp_test;

  // State itself will be deleted by XPtr destructor

  return R_NilValue;
}

#endif
